# truYum-SpringCore-CaseStudy
## truYum Case Study Spring Core
### > Menu Driven Application
### > Used only Spring Core
