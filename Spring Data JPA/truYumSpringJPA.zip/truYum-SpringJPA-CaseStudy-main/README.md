# truYum-SpringJPA-CaseStudy
## truYum SpringJPA CaseStudy Solution
### Spring Data JPA Specification of the truYum Application is implemented here
